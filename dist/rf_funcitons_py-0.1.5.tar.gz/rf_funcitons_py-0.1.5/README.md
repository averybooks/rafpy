#My First Package
This package contains my alias source signal identification function
